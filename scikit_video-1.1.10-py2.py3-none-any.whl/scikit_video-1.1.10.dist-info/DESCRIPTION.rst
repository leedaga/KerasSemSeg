This library provides easy access to common as well as
state-of-the-art video processing routines. Check out the
website for more details.



